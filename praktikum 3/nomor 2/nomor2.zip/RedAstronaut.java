public class RedAstronaut extends Player implements Impostor {
    private String expertise; // added expertise field

    public RedAstronaut(String name, int susLevel, String expertise) {
        super(name, susLevel);
        this.expertise = expertise; // assign expertise
    }

    @Override
    public void emergencyMeeting() {
        // Implementation of emergency meeting for RedAstronaut
    }

    @Override
    public void freeze(Player p) {
        // Implementation of freeze for RedAstronaut
    }

    @Override
    public void sabotage(Player p) {
        // Implementation of sabotage for RedAstronaut
    }
}
