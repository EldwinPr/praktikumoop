public class BlueAstronaut extends Player implements Crewmate {
    private int numTasks; // added numTasks field
    private int numCompletedTasks; // added numCompletedTasks field

    public BlueAstronaut(String name, int susLevel, int numTasks, int numCompletedTasks) {
        super(name, susLevel);
        this.numTasks = numTasks; // assign numTasks
        this.numCompletedTasks = numCompletedTasks; // assign numCompletedTasks
    }

    @Override
    public void emergencyMeeting() {
        // Implementation of emergency meeting for BlueAstronaut
    }

    @Override
    public void completeTask() {
        // Implementation of completeTask for BlueAstronaut
    }
}
